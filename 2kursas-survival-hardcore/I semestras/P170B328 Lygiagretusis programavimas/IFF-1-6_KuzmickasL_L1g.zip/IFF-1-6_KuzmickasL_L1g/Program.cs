﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace kolis
{


    
    class Program
    {
        public static void Main(string[] args)
        {
            
            int count = 0;
            

            WorkerThread firstThread = new WorkerThread();
            WorkerThread secondThread = new WorkerThread();
            WorkerThread thirdThread = new WorkerThread();
            WorkerThread forthThread = new WorkerThread();
            WorkerThread fifthThread = new WorkerThread();


            Thread pirmaGija = new Thread(firstThread.ExecuteFirst);
            Thread antraGija = new Thread(secondThread.ExecuteSecond);
            Thread treciaGija = new Thread(thirdThread.ExecuteThird);
            Thread ketvirtaGija = new Thread(forthThread.ExecuteForth);
            Thread penktaGija = new Thread(fifthThread.ExecuteFifth);

            
          
            while (count < 15)
            {
                pirmaGija.Start();
                antraGija.Start();
                treciaGija.Start();
                ketvirtaGija.Start();
                penktaGija.Start();
                count++;
            }

            pirmaGija.Join();
            antraGija.Join();
            treciaGija.Join();
            ketvirtaGija.Join();
            penktaGija.Join();

            fifthThread.FinishWork();
        }



    }


    class WorkerThread
    {
        object monitor = "*";
        string addObject1 = "abcdefghijklmnopqrstuwxyz";
        string addObject2 = "ABCDEFGHHIJKLMNOPQRSTUWXYZ";
        string addObject3 = "0123456789";
        int i = 0;
        int j = 0;
        int k = 0;
        public void ExecuteFirst()
        {
            MainThread.AddSymbol(monitor.ToString(), addObject1, ref i);
        }

        public void ExecuteSecond()
        {
            MainThread.AddSymbol(monitor.ToString(), addObject2, ref j);
        }

        public void ExecuteThird()
        {
            MainThread.AddSymbol(monitor.ToString(), addObject3, ref k);
        }

        public void ExecuteForth()
        {
            MainThread.PrintThread(monitor.ToString());
        }

        public void ExecuteFifth()
        {
            MainThread.PrintThread(monitor.ToString());
        }

        public void FinishWork()
        {
            Monitor.PulseAll(monitor);
            Console.WriteLine("Darbas baigtas!");
        }
    }

    class MainThread
    {
        public static string ReadString(string kint)
        {
            lock (kint)
            {
                return kint;
            }
        }

        public static void AddSymbol(string monitorius, string objektas, ref int i)
        {
            lock (monitorius)
            {
                int currentObject = objektas.Length - i;
                monitorius.Append(objektas[currentObject]);
                Monitor.Wait(monitorius);
                i++;
                Monitor.Pulse(monitorius);
            }
        }



        public static void PrintThread(string monitorius)
        {
            lock (monitorius)
            {
                Console.WriteLine(monitorius);
                Monitor.Pulse(monitorius);
            }
        }


    }
    

}
