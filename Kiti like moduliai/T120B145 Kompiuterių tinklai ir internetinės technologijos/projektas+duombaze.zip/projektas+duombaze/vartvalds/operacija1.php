  <html>  
        <head> 
            <style>
            #zinutes {
            font-family: Arial; border-collapse: collapse; width: 70%;
            }
            #zinutes td {
            border: 1px solid #ddd; padding: 8px;
            }   
            #zinutes tr:nth-child(even){background-color: #f2f2f2;}
            #zinutes tr:hover {background-color: #ddd;}
            #zinutes tr:first-child{background-color: yellow;}
            .back-button {
            position: absolute;
            top: 10px;
            right: 10px;
            text-decoration: none;
            padding: 10px 20px;
            background-color: #f2f2f2;
            border: 1px solid #999;
            border-radius: 5px;
        }
            </style> 
        <meta http-equiv="X-UA-Compatible" content="IE=9; text/html; charset=utf-8"/> 
        <title>Operacija3</title>
        <link href="include/styles.css" rel="stylesheet" type="text/css" />
        </head>
        <body>
        <a href="index.php">Sugrįžti</a>&nbsp;&nbsp;        
        <center><h3>Kursai</h3></center>
            <table style="margin: 0px auto;" id="zinutes">
            <tr>
                <td><b>Pavadinimas</b></th>
                <td><b>Aprašas</b></th>
                <td><b>Laikas</b></th>
                <td><b>Kaina</b></th>
                <td><b>Vietų skaičius</b></th>
            </tr>
            <?php
    $server = "localhost";
    $db = "vartvalds";
    $user = "stud";
    $password = "stud";
    $mokymai = "mokymai";

    // prisijungimas prie DB
    $dbc = mysqli_connect($server, $user, $password, $db);
    if (!$dbc) {
        die("Negaliu prisijungti prie MySQL:" . mysqli_error($dbc));
    }

    $sql = "SELECT * FROM $mokymai";
    $result = mysqli_query($dbc, $sql);

    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>" . $row['pavadinimas'] . "</td>";
        echo "<td>" . $row['aprasas'] . "</td>";
        echo "<td>" . $row['laikas'] . "</td>";
        echo "<td>" . $row['kaina'] . "</td>";
        echo "<td>" . $row['vietos'] . "</td>";
        echo "</tr>";
       
    }
    echo "</table>";
    exit();
    ?>
</body>
</html>


