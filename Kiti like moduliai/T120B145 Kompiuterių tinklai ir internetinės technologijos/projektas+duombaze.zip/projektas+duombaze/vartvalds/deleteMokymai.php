<?php
// Establish your database connection
$servername = "localhost";
$username = "stud";
$password = "stud";
$dbname = "vartvalds";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// Check if the ID is provided in the URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Delete the record from the database based on the provided ID
    $sql = "DELETE FROM mokymai WHERE id = $id";

    if ($conn->query($sql) === TRUE) {
        header('Location: operacija3.php');
    } else {
        echo "Error deleting record: " . $conn->error;
    }
}

// Close the database connection
$conn->close();
?>