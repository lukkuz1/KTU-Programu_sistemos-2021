<!DOCTYPE html>
<html>
<head>
    <title>Registracija į seminarą</title>
</head>
<body>
 
<form action="operacija2.php" method="get">
    <label for="mokymu_id">Pasirinkite seminarą:</label>
    <select name="mokymu_id" id="mokymu_id">
        <?php
        // Assuming you've included session.php and established a database connection
 
        // Sample database connection
        $servername = "localhost";
        $username = "stud";
        $password = "stud";
        $dbname = "vartvalds";
 
        $conn = new mysqli($servername, $username, $password, $dbname);
 
        if ($conn->connect_error) {
            die("Nepavyko prisijungti: " . $conn->connect_error);
        }
 
        // Fetch seminar information from the database
        $sql = "SELECT vartotoju_id, id FROM vartotoju_mokymai"; // Adjust based on your database structure
        $result = $conn->query($sql);
 
        // Check if there are any results
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo '<option value="' . $row["vartotoju_id"] . '">' . $row["id"] . '</option>';
            }
        } else {
            echo '<option value="">No seminars available</option>';
        }
 
        $conn->close(); // Close the database connection
        ?>
    </select>
    <input type="submit" value="Registruotis">
</form>
 
</body>
</html>