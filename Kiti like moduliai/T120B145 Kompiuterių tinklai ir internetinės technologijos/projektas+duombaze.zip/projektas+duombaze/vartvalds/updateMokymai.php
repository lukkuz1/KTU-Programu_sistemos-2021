<?php
$servername = "localhost";
$username = "stud";
$password = "stud";
$dbname = "vartvalds";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['id'])) {
        $id = $_POST['id'];
        $pavadinimas = $_POST['pavadinimas'];
        $vietos = $_POST['vietos'];
        $laikas = $_POST['laikas'];
        $kaina = $_POST['kaina'];
        $aprasas = $_POST['aprasas'];

        $sql = "UPDATE mokymai SET pavadinimas='$pavadinimas' , vietos='$vietos', laikas='$laikas', kaina='$kaina', aprasas='$aprasas' WHERE id=$id";

        if ($conn->query($sql) === TRUE) {
            echo "Record updated successfully";
        } else {
            echo "Error updating record: " . $conn->error;
        }
    }
}
$conn->close();
?>