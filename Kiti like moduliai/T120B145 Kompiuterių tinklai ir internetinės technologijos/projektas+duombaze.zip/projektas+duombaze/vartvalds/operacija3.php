<?php
include("include/session.php");
//Jei prisijunges Administratorius
if ($session->logged_in && $session->isAdmin()) {
    ?>    
    <html>  
        <head>

        <link rel="stylesheet"
        href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js">
        </script>
        <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js">
        </script>
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css
        ">
        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <!-- Latest compiled JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>


            <style>
            #zinutes {
            font-family: Arial; border-collapse: collapse; width: 70%;
            }
            #zinutes td {
            border: 1px solid #ddd; padding: 8px;
            }   
            #zinutes tr:nth-child(even){background-color: #f2f2f2;}
            #zinutes tr:hover {background-color: #ddd;}
            #zinutes tr:first-child{background-color: yellow;}
            </style> 
        <meta http-equiv="X-UA-Compatible" content="IE=9; text/html; charset=utf-8"/> 
        <title>Operacija3</title>
        <link href="include/styles.css" rel="stylesheet" type="text/css" />
        </head>
        <body>
        <a href="index.php">Sugrįžti</a>&nbsp;&nbsp;        
        <center><h3>Kursai</h3></center>
            <table style="margin: 0px auto;" id="zinutes">
            <tr>
                <td><b>Pavadinimas</b></th>
                <td><b>Vietų skaičius</b></th>
                <td><b>Laikas</b></th>
                <td><b>Kaina</b></th>
                <td><b>Aprašas</b></th>
                <td><b>Šalinimas</b></th>
            </tr>
            <?php
    $server = "localhost";
    $db = "vartvalds";
    $user = "stud";
    $password = "stud";
    $mokymai = "mokymai";

    // prisijungimas prie DB
    $dbc = mysqli_connect($server, $user, $password, $db);
    if (!$dbc) {
        die("Negaliu prisijungti prie MySQL:" . mysqli_error($dbc));
    }

    $sql = "SELECT * FROM $mokymai";
    $result = mysqli_query($dbc, $sql);

    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>" . $row['pavadinimas'] . "</td>";
        echo "<td>" . $row['vietos'] . "</td>";
        echo "<td>" . $row['laikas'] . "</td>";
        echo "<td>" . $row['kaina'] . "</td>";
        echo "<td>" . $row['aprasas'] . "</td>";
        echo "<td><a href='deleteMokymai.php?id=" . $row['id'] . "'>Ištrinti</a></td>";
        echo "</tr>";
    }
    // prisijungimas prie DB
$dbc=mysqli_connect($server,$user,$password, $db);
if(!$dbc){ die ("Negaliu prisijungti prie MySQL:"
.mysqli_error($dbc)); }
if($_POST !=null){
$pavadinimas = $_POST['pavadinimas'];
$aprasas =$_POST['aprasas'];
$laikas = $_POST['laikas'];
$kaina =$_POST['kaina'];
$vietos =$_POST['vietos'];
//nuskaityti likusias užklausos reikšmes
$sql = "INSERT INTO $mokymai (pavadinimas,aprasas,laikas,kaina,vietos) VALUES ('$pavadinimas', '$aprasas','$laikas','$kaina','$vietos')";
if (!mysqli_query($dbc, $sql)) die ("Klaida įrašant:".mysqli_error($dbc));
echo "Įrašyta";
header('Location: operacija3.php');
exit();
}
?>

<div class="container">
 <form method='post'>
<div class="form-group col-lg-4">
     <label for="pavadinimas" class="control-label">Pavadinimas</label>
    <textarea name='pavadinimas' class="form-control input-sm" required></textarea>
</div>

<div class="form-group col-lg-4">
    <label for="vietos" class="control-label">Vietos</label>
    <input name='vietos' id="vietos" type='number' class="form-control input-sm" min="0" required>
</div>
<div class="form-group col-lg-4">
    <label for="kaina" class="control-label">Kaina</label>
    <input name='kaina' type='number' class="form-control input-sm" min="0" required>
</div>
<div class="form-group col-lg-4">
    <label for="laikas" class="control-label">Laikas</label>
    <input name='laikas' type='datetime-local' class="form-control input-sm" required>
</div>
 <div class="form-group col-lg-12">
 <label for="aprasas" class="control-label">Aprašas</label>
 <textarea name='aprasas' class="form-control input-sm" required></textarea>
 </div>
 <div class="form-group col-lg-2">
 <input type='submit' name='ok' value='Įrašyti' class="btnbtn-default">
 </div>

</body>
    </html>
    <?php
    //Jei vartotojas neprisijungęs arba prisijunges, bet ne Administratorius 
    //ar ne Valdytojas - užkraunamas pradinis puslapis   
} else {
    header("Location: index.php");
}
?>

