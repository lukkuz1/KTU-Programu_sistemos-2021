<?php
include("include/session.php");
// Check if the user is an administrator
if ($session->logged_in && $session->isAdmin()) {
// Connect to the database
$servername = "localhost";
$username = "stud";
$password = "stud";
$dbname = "vartvalds";
 
$conn = new mysqli($servername, $username, $password, $dbname);
 
if ($conn->connect_error) {
    die("Nepavyko prisijungti: " . $conn->connect_error);
}
 
// Fetch registration details
$sql = "SELECT vm.vartotoju_id,m.pavadinimas, m.aprasas, m.laikas, m.kaina, m.vietos
        FROM vartotoju_mokymai vm
        JOIN mokymai m ON vm.mokymu_id = m.id";
$result = $conn->query($sql);
?>
 
<!DOCTYPE html>
<html>
<head>
    <title>Registracijos</title>
    <link rel="stylesheet"
        href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js">
        </script>
        <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js">
        </script>
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css
        ">
        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <!-- Latest compiled JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <style>
            #zinutes {
            font-family: Arial; border-collapse: collapse; width: 70%;
            }
            #zinutes td {
            border: 1px solid #ddd; padding: 8px;
            }   
            #zinutes tr:nth-child(even){background-color: #f2f2f2;}
            #zinutes tr:hover {background-color: #ddd;}
            #zinutes tr:first-child{background-color: yellow;}
        </style> 
</head>

<body>
    <center><a href="index.php">Sugrįžti</a></center>&nbsp;&nbsp;
    <center><h1>Registracijos į mokymus</h1></center>
    <center><table id="zinutes" border="1"></center>
        <tr>
            <td >Vartotojas</td>
            <td >Pavadinimas</td>
            <td >Seminaro aprašas</td>
            <td >Laikas</td>
            <td >Kaina</td>
            <td >Vietos</td>
        </tr>
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo '<tr>';
                echo '<td>' . $row["vartotoju_id"] . '</td>';
                echo '<td>' . $row["pavadinimas"] . '</td>';
                echo '<td>' . $row["aprasas"] . '</td>';
                echo '<td>' . $row["laikas"] . '</td>';
                echo '<td>' . $row["kaina"] . '</td>';
                echo '<td>' . $row["vietos"] . '</td>';
                echo '</tr>';
            }
        } else {
            echo '<tr><td colspan="4">Nėra registracijų</td></tr>';
        }
        $conn->close();
        ?>
    </table>
    
</body>
<?php
} else {
    header("Location: index.php");
}
?>

</html>