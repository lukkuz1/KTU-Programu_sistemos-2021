<?php
include("include/session.php");
 
$message = ""; // Variable to store status message
 
if ($session->logged_in && $session->isUser()) {
    $servername = "localhost";
    $username = "stud";
    $password = "stud";
    $dbname = "vartvalds";
 
    $conn = new mysqli($servername, $username, $password, $dbname);
 
    if ($conn->connect_error) {
        die("Nepavyko prisijungti: " . $conn->connect_error);
    }
 
    if (isset($_GET['mokymu_id'])) {
        $vartotoju_id = $_SESSION['username'];
        $mokymu_id = $_GET['mokymu_id'];
 
        $check_existing = $conn->prepare("SELECT * FROM vartotoju_mokymai WHERE vartotoju_id = ? AND mokymu_id = ?");
        $check_existing->bind_param("si", $vartotoju_id, $mokymu_id);
        $check_existing->execute();
        $check_existing->store_result();
 
        if ($check_existing->num_rows > 0) {
            $message = "<center><b>Jūs jau esate užsiregistravęs į šį kursą!</b></center>";
        } else {
            // Check available slots before registration
            $check_slots = $conn->prepare("SELECT vietos FROM mokymai WHERE id = ? AND vietos > 0");
            $check_slots->bind_param("i", $mokymu_id);
            $check_slots->execute();
            $check_slots->store_result();
 
            if ($check_slots->num_rows > 0) {
                $stmt = $conn->prepare("INSERT INTO vartotoju_mokymai (vartotoju_id, mokymu_id) VALUES (?, ?)");
                $stmt->bind_param("si", $vartotoju_id, $mokymu_id);
                $stmt->execute();
 
                if ($stmt->affected_rows > 0) {
                    $update_slots = $conn->prepare("UPDATE mokymai SET vietos = vietos - 1 WHERE id = ?");
                    $update_slots->bind_param("i", $mokymu_id);
                    $update_slots->execute();
                    $update_slots->close();
 
                    $message = "<center><b>Sėkmingai užsiregistravote į kursą!</b></center>";
                } else {
                    $message = "<center><b>Registracija nepavyko. Bandykite dar kartą.</b></center>";
                }
                $stmt->close();
            } else {
                $message = "<center><b>Vietų nėra. Registracija negalima.</b></center>";
            }
            $check_slots->close();
        }
        $check_existing->close();
    } else {
        $message = "<center><b>Pasirinkite kursą.</b></center>";
    }
 
    $conn->close();
} else {
    header("Location: index.php");
}
?>
 
<!DOCTYPE html>
<html>
<head>
    <center><a href="index.php">Sugrįžti</a></center>&nbsp;&nbsp;
    <title>Registracija į mokymą</title>
    <link rel="stylesheet"
        href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js">
        </script>
        <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js">
        </script>
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css
        ">
        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <!-- Latest compiled JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>


            <style>
            #zinutes {
            font-family: Arial; border-collapse: collapse; width: 70%;
            }
            #zinutes td {
            border: 1px solid #ddd; padding: 8px;
            }   
            #zinutes tr:nth-child(even){background-color: #f2f2f2;}
            #zinutes tr:hover {background-color: #ddd;}
            #zinutes tr:first-child{background-color: yellow;}
            </style> 

</head>
<body>
    <p><?php echo $message; ?></p>
 
    <center><table id="zinutes" border="1"></center>
        <tr>
            <td>Pavadinimas</td>
            <td>Aprašas</td>
            <td>Vietų kiekis</td>
            <td>Kaina</td>
            <td>Laikas</td>
            <td>Registracija</td>
        </tr>
        <?php
        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
            die("Nepavyko prisijungti: " . $conn->connect_error);
        }
 
        $sql = "SELECT id, pavadinimas, aprasas, vietos, kaina, laikas FROM mokymai";
        $result = $conn->query($sql);
 
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo '<tr>';
                echo '<td>' . $row["pavadinimas"] . '</td>';
                echo '<td>' . $row["aprasas"] . '</td>';
                echo '<td>' . $row["vietos"] . '</td>';
                echo '<td>' . $row["kaina"] . '</td>';
                echo '<td>' . $row["laikas"] . '</td>';
                echo '<td><a href="operacija2.php?mokymu_id=' . $row["id"] . '">Registruotis</a></td>';
                echo '</tr>';
            }
        } else {
            echo '<tr><td colspan="3">nera mokymu</td></tr>';
        }
        $conn->close();
        ?>
    </table>
</body>
</html>