-- phpMyAdmin SQL Dump
-- version 4.6.6deb5ubuntu0.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 09, 2023 at 09:06 PM
-- Server version: 5.7.35-0ubuntu0.18.04.1
-- PHP Version: 7.2.24-0ubuntu0.18.04.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vartvalds`
--

-- --------------------------------------------------------

--
-- Table structure for table `active_guests`
--

CREATE TABLE `active_guests` (
  `ip` varchar(15) NOT NULL,
  `timestamp` int(11) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `active_guests`
--

INSERT INTO `active_guests` (`ip`, `timestamp`) VALUES
('::1', 1699556711);

-- --------------------------------------------------------

--
-- Table structure for table `active_users`
--

CREATE TABLE `active_users` (
  `username` varchar(30) NOT NULL,
  `timestamp` int(11) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `banned_users`
--

CREATE TABLE `banned_users` (
  `username` varchar(30) NOT NULL,
  `timestamp` int(11) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `mokymai`
--

CREATE TABLE `mokymai` (
  `id` int(11) NOT NULL,
  `pavadinimas` text NOT NULL,
  `aprasas` text NOT NULL,
  `laikas` datetime NOT NULL,
  `kaina` int(3) NOT NULL,
  `vietos` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mokymai`
--

INSERT INTO `mokymai` (`id`, `pavadinimas`, `aprasas`, `laikas`, `kaina`, `vietos`) VALUES
(42, 'ISP', 'ISP modulis KTU', '2023-11-09 20:58:00', 250, 149);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `username` varchar(30) NOT NULL,
  `password` varchar(32) DEFAULT NULL,
  `userid` varchar(32) DEFAULT NULL,
  `userlevel` tinyint(1) UNSIGNED NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `timestamp` int(11) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`username`, `password`, `userid`, `userlevel`, `email`, `timestamp`) VALUES
('Administratorius', 'fe01ce2a7fbac8fafaed7c982a04e229', 'f238ff41ca175b840c0d7dc3cff10777', 9, 'ashepidor@gmail.com', 1699556602),
('Vartotojas', 'fe01ce2a7fbac8fafaed7c982a04e229', '3b3ce09985dd28bf1805fb4e9b089554', 1, 'm@gmail.com', 1699554613),
('admin', '21232f297a57a5a743894a0e4a801fc3', 'a67cfb8dbf2afe949ea8f252af5ebe6b', 1, 'm@gmail.com', 1699437424),
('lukkuz1', '879a95557ae4cba451831e518be9f795', '7fb929fafc91e058ea56fe84d52064c3', 1, 'lukas6bkuzmickas@gmail.com', 1699556711);

-- --------------------------------------------------------

--
-- Table structure for table `vartotoju_mokymai`
--

CREATE TABLE `vartotoju_mokymai` (
  `id` int(11) NOT NULL,
  `vartotoju_id` varchar(30) NOT NULL,
  `mokymu_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vartotoju_mokymai`
--

INSERT INTO `vartotoju_mokymai` (`id`, `vartotoju_id`, `mokymu_id`) VALUES
(79, 'lukkuz1', 42);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `active_guests`
--
ALTER TABLE `active_guests`
  ADD PRIMARY KEY (`ip`);

--
-- Indexes for table `active_users`
--
ALTER TABLE `active_users`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `banned_users`
--
ALTER TABLE `banned_users`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `mokymai`
--
ALTER TABLE `mokymai`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `vartotoju_mokymai`
--
ALTER TABLE `vartotoju_mokymai`
  ADD PRIMARY KEY (`id`),
  ADD KEY `vartotoju_id` (`vartotoju_id`),
  ADD KEY `mokymu_id` (`mokymu_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `mokymai`
--
ALTER TABLE `mokymai`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;
--
-- AUTO_INCREMENT for table `vartotoju_mokymai`
--
ALTER TABLE `vartotoju_mokymai`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `vartotoju_mokymai`
--
ALTER TABLE `vartotoju_mokymai`
  ADD CONSTRAINT `vartotoju_mokymai_ibfk_1` FOREIGN KEY (`mokymu_id`) REFERENCES `mokymai` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
