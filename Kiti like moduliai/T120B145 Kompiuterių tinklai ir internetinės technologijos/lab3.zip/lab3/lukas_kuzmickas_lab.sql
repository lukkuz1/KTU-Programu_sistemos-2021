-- phpMyAdmin SQL Dump
-- version 4.6.6deb5ubuntu0.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 24, 2023 at 11:34 AM
-- Server version: 5.7.35-0ubuntu0.18.04.1
-- PHP Version: 7.2.24-0ubuntu0.18.04.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `stud`
--

-- --------------------------------------------------------

--
-- Table structure for table `lukas_kuzmickas_lab`
--

CREATE TABLE `lukas_kuzmickas_lab` (
  `id` int(11) NOT NULL,
  `created` date NOT NULL,
  `ip` varchar(20) NOT NULL,
  `studentname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lukas_kuzmickas_lab`
--

INSERT INTO `lukas_kuzmickas_lab` (`id`, `created`, `ip`, `studentname`, `email`, `message`) VALUES
(23, '2023-11-15', 'da2421', 'fasfas', '12ga@gmail.com', 'asdasdsad'),
(52, '2023-11-16', '111.521.5125:26012', 'lukas', 'ashepidor@gmail.com', 'adasdasd'),
(53, '2023-11-16', '111.521.5125:26012', 'lukas', 'ashepidor@gmail.com', 'adasdasd'),
(54, '2023-11-15', 'da2421', 'fasfas', '12ga@gmail.com', 'asdasdsad'),
(55, '2023-11-24', '127.0.0.1', 'lukkuz1', 'lukkuz1@ktu.lt', 'asdasdasd'),
(56, '2023-11-24', '127.0.0.1', 'dasd', 'asda@gmail.com', 'asdasd'),
(57, '2023-11-24', '::1', 'Lukas', 'makrib1@ktu.lt', 'Labas rytas!'),
(58, '2023-11-24', '::1', 'Deividas', 'makrib1@ktu.lt', 'Labas rytas!'),
(59, '2023-11-24', '::1', 'ArÅ«nas', 'arunas@ktu.lt', 'Labas');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `lukas_kuzmickas_lab`
--
ALTER TABLE `lukas_kuzmickas_lab`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `lukas_kuzmickas_lab`
--
ALTER TABLE `lukas_kuzmickas_lab`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
