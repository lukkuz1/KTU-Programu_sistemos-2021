<?php
$result = array();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once('config.php');
    $dbc = @mysqli_connect(HOSTNAME, USERNAME, PASSWORD, DATABASE);
    
    if (!$dbc) {
        $result = array('error' => "Cannot connect: " . mysqli_error($dbc));
 } else {
        $created = date("Y-m-d");
        $ip = $_SERVER['REMOTE_ADDR'];
        $studentname = $_POST['vardas'];
        $email = $_POST['pastas'];
        $message = $_POST['zinute'];

        $query = "INSERT INTO lukas_kuzmickas_lab (created, ip, studentname, email, message) VALUES ('$created', '$ip', '$studentname', '$email', '$message')";

        $result = array();
         if (mysqli_query($dbc, $query)) {
            $result = array('success' => "Record inserted successfully");
        } else {
            $result = array('error' => "Error: " . mysqli_error($dbc));
        }

        mysqli_close($dbc);
    }
}
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
echo json_encode($result);
?>