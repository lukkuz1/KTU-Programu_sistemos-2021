<?php
define('HOSTNAME', 'localhost');
define('USERNAME', 'stud');
define('PASSWORD', 'stud');
define('DATABASE', 'stud');
?>