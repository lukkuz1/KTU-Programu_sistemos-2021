<?php

$messages = array();
require_once('config.php');
$dbc = @mysqli_connect(HOSTNAME, USERNAME, PASSWORD, DATABASE);
mysqli_set_charset($dbc,"utf8"); 

if(!$dbc )
{
      $result = array('error' => "Cannot connect: ".mysqli_error($dbc));
      echo json_encode($result);
      exit();
}
$query = 'SELECT * FROM lukas_kuzmickas_lab order by id desc';
$result = @mysqli_query($dbc, $query);

while($row = mysqli_fetch_array($result))
{
     $messages[] = $row;
}
mysqli_close($dbc);




header("Content-Type: application/json");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");  
echo json_encode($messages);
?>